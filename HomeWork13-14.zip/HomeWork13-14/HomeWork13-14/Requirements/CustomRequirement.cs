﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork13_14.Requirements
{
    public class CustomRequirement : IAuthorizationRequirement
    {
        protected internal int Age { get; set; }
        public CustomRequirement(int age)
        {
            Age = age;
        }
    }
}
