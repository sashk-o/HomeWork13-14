﻿using HomeWork13_14.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HomeWork13_14.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly ApplicationDbContext dbContext;

        public AccountController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
        {
            var user = await dbContext.Users
                .Include(i => i.Roles)
                .FirstOrDefaultAsync(i => i.Email == loginModel.Email && i.Password == loginModel.Password);

            if (user == null)
            {
                return BadRequest();
            }

            var claims = GetClaims(user);

            var claimsIdentity = new ClaimsIdentity(claims, "ApplicationCookies", ClaimsIdentity.DefaultNameClaimType, ClaimsIdentity.DefaultRoleClaimType);

            var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);

            return Ok();
        }
        private List<Claim> GetClaims(User user)
        {
            var roleClaims = user.Roles.Select(i =>
                new Claim(ClaimTypes.Role, i.Name));

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Email),
                new Claim("Password", user.Password),
                new Claim(ClaimTypes.DateOfBirth, user.Age.ToString())
            };

            claims.AddRange(roleClaims);

            return claims;
        }
    }
}
