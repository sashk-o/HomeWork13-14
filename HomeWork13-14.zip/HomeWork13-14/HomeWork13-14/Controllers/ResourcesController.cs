﻿using HomeWork13_14.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork13_14.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ResourcesController : ControllerBase
    {
        private readonly ApplicationDbContext dbContext;
        public ResourcesController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        [Route("[action]")]
        [Authorize(Roles = "free")]
        public IActionResult GetFree()
        {
            return Content("This is content for free users");
        }

        [HttpGet]
        [Route("[action]")]
        [Authorize(Roles = "premium")]
        public IActionResult GetPremium()
        {
            return Content("This is content for Premium users");
        }

        [HttpGet]
        [Route("[action]")]
        [Authorize(Roles = "admin")]
        public IActionResult GetAllUsers()
        {
            var users = dbContext.Users.ToList();
            foreach (var user in users)
            {
                Console.WriteLine($"Email: {user.Email}, Password: {user.Password}");
            }
            return Ok();
        }
        [HttpGet]
        [Route("[action]")]
        [Authorize(Policy = "AgeLimit")]
        public IActionResult GetLimitedContent()
        {
            return Content("This is content for premium 18+ users");
        }
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetOpenContent()
        {
            return Content("This is content for all users");
        }
    }
}

